# AI Travel Analyst — VIT Chennai AIML Recruitment Challenge

## Track
**Data Science & Visualisation — AI Travel Analyst**

This project analyzes flight-price data, creates five visualizations, performs feature engineering, trains a prediction model, explains the main drivers using model feature importance, and implements the Part 3 **Cheapest Booking Time Analysis** option.

## Why this track?
It covers the challenge requirements without requiring a local LLM, Ollama, an API key, or GPU. The application is a Streamlit web app and uses scikit-learn for the predictive pipeline.

## Requirements covered
- Part 1: data cleaning/preprocessing
- Part 1: at least five meaningful visualizations
- Part 1: identify factors affecting flight prices
- Part 1: present insights/recommendations
- Part 2: feature engineering
- Part 2: prediction model
- Part 2: train/evaluate model
- Part 2: explain important predictive features
- Part 3: Cheapest Booking Time Analysis
- Stretch-ready architecture: interactive dashboard and model explainability

## Important dataset note
The challenge brief says the recommended dataset is mandatory for Part 1 and supplies a Google Drive folder. The folder was not programmatically accessible while this project was generated. Therefore the repository contains a tiny demo dataset in code so the app remains runnable, but **you must replace it with the official challenge dataset before submission**. The app's CSV uploader is designed for this.

## Tech stack
Python, Pandas, NumPy, Matplotlib, Scikit-learn, Streamlit, Pytest.

Streamlit is used because it supports interactive Python data applications and can be run with `streamlit run app.py`. See the official docs: https://docs.streamlit.io/get-started/installation

## Installation
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
streamlit run app.py
```

Upload the official challenge CSV from the sidebar.

## Test
```bash
pytest -q
```

## Methodology
1. Normalize column names and common aliases.
2. Parse journey dates, duration, and number of stops.
3. Remove duplicates and invalid target rows.
4. Split numeric and categorical features.
5. Impute missing values and one-hot encode categorical variables.
6. Train a Random Forest regression model.
7. Report MAE and R² on a held-out test set.
8. Use grouped analysis for price insights and cheapest booking-time analysis.

## Results
Results are intentionally generated from the official uploaded dataset rather than fabricated in advance. The UI reports MAE and R² after training. This makes the submission reproducible and avoids claiming an unsupported accuracy number.

## Limitations
- Flight prices are highly time-dependent and the dataset may not represent today's market.
- Random train/test splitting can be optimistic for temporal data.
- Booking-time analysis is observational, not causal.
- Recommendations should support, not replace, traveler decisions.

## Future improvements
- Time-aware validation.
- Gradient boosting/XGBoost comparison.
- SHAP explanations.
- Live price ingestion from permitted sources.
- Route-specific forecasting.
- Deployment with Streamlit Community Cloud.

## Submission checklist
- [ ] Replace demo data with the mandatory challenge dataset.
- [ ] Run `pytest -q`.
- [ ] Run the Streamlit app and take screenshots.
- [ ] Record a 3–5 minute demo video.
- [ ] Push this repository to a public GitHub repository.
- [ ] Verify README and requirements are complete.
