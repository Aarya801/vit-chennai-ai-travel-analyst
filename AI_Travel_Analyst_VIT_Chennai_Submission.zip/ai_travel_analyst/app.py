import io
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from src.pipeline import clean_data, build_model, recommend_cheapest

st.set_page_config(page_title='AI Travel Analyst', page_icon='✈️', layout='wide')
st.title('✈️ AI Travel Analyst')
st.caption('Flight-price exploration, prediction, explainability, and cheapest-booking analysis — no paid API or local LLM required.')

@st.cache_data

def load_uploaded(raw):
    return clean_data(pd.read_csv(io.BytesIO(raw)))

sample = pd.DataFrame({
    'Airline':['IndiGo','Air India','Vistara','SpiceJet','IndiGo','Air India','Vistara','GoAir','SpiceJet','IndiGo'],
    'Source':['Delhi','Delhi','Mumbai','Delhi','Mumbai','Bangalore','Delhi','Mumbai','Bangalore','Delhi'],
    'Destination':['Mumbai','Bangalore','Delhi','Kolkata','Delhi','Delhi','Bangalore','Delhi','Mumbai','Hyderabad'],
    'Total_Stops':['non-stop','1 stop','non-stop','1 stop','non-stop','1 stop','1 stop','non-stop','1 stop','non-stop'],
    'Duration':['2h 10m','5h 15m','2h 20m','6h 0m','2h 5m','5h 0m','4h 30m','2h 15m','5h 40m','2h 0m'],
    'Price':[4200,7600,5200,6800,3900,7200,6400,4500,7000,4100],
})

with st.sidebar:
    st.header('Dataset')
    uploaded = st.file_uploader('Upload CSV', type=['csv'])
    if uploaded:
        df = load_uploaded(uploaded.getvalue())
        st.success(f'{len(df):,} rows loaded')
    else:
        df = clean_data(sample)
        st.info('Using built-in demo data. Replace it with the mandatory club dataset before submission.')

if 'Price' not in df.columns:
    st.error('Dataset must contain a Price column.')
    st.stop()

st.subheader('1. Exploration & Cleaning')
c1,c2,c3 = st.columns(3)
c1.metric('Rows', f'{len(df):,}')
c2.metric('Columns', f'{len(df.columns)}')
c3.metric('Median Price', f'₹{df.Price.median():,.0f}')
st.dataframe(df.head(20), use_container_width=True)

st.subheader('2. Five required visualizations')
fig, ax = plt.subplots(); df['Price'].plot(kind='hist', bins=25, ax=ax); ax.set_title('1. Price distribution'); ax.set_xlabel('Price'); st.pyplot(fig); plt.close(fig)
if 'Airline' in df:
    fig, ax = plt.subplots(); df.groupby('Airline')['Price'].mean().sort_values().plot(kind='bar', ax=ax); ax.set_title('2. Average price by airline'); ax.set_ylabel('Average price'); st.pyplot(fig); plt.close(fig)
if 'Total_Stops' in df:
    fig, ax = plt.subplots(); df.groupby('Total_Stops')['Price'].mean().plot(kind='bar', ax=ax); ax.set_title('3. Average price by number of stops'); st.pyplot(fig); plt.close(fig)
if 'Source' in df and 'Destination' in df:
    route = df.groupby(['Source','Destination'])['Price'].mean().sort_values().head(10)
    fig, ax = plt.subplots(); route.plot(kind='barh', ax=ax); ax.set_title('4. Cheapest average routes'); ax.set_xlabel('Average price'); st.pyplot(fig); plt.close(fig)
if 'Duration_Min' in df:
    fig, ax = plt.subplots(); ax.scatter(df['Duration_Min'], df['Price'], alpha=.5); ax.set_title('5. Duration vs price'); ax.set_xlabel('Duration (minutes)'); ax.set_ylabel('Price'); st.pyplot(fig); plt.close(fig)

st.subheader('3. Modeling')
model, metrics = build_model(df)
m1,m2 = st.columns(2); m1.metric('R²', f"{metrics['r2']:.3f}"); m2.metric('MAE', f"₹{metrics['mae']:,.0f}")
st.write('The model uses one-hot encoding for categorical features, median imputation for numeric features, and a Random Forest regressor.')

st.subheader('4. Part 3 — Cheapest Booking Time Analysis')
if 'Dep_Time' in df.columns:
    x=df.copy(); x['Dep_Hour']=pd.to_datetime(x['Dep_Time'].astype(str), errors='coerce').dt.hour
    hour=x.dropna(subset=['Dep_Hour']).groupby('Dep_Hour')['Price'].mean().sort_values()
    if not hour.empty:
        st.dataframe(hour.rename('Average Price').reset_index(), use_container_width=True)
        fig, ax = plt.subplots(); hour.plot(kind='line', marker='o', ax=ax); ax.set_title('Average price by departure hour'); ax.set_xlabel('Departure hour'); st.pyplot(fig); plt.close(fig)
else:
    st.info('Upload the club dataset with Dep_Time to unlock time-of-day analysis.')

st.subheader('5. Cheapest Recommendations')
st.dataframe(recommend_cheapest(df, 10), use_container_width=True)
st.caption('This tool is a decision-support prototype, not a guarantee of future ticket prices.')
