# Project Report — AI Travel Analyst

## Project Overview
AI Travel Analyst is an interactive flight-price analytics system. It converts raw flight records into clean analytical features, visualizes price patterns, trains a regression model, and provides a simple booking-time recommendation view.

## Problem Statement
Travelers see many flight options but prices vary with airline, route, stops, duration, and timing. The project aims to uncover these patterns and turn them into understandable recommendations.

## Dataset Used
The challenge brief specifies a mandatory club dataset in a Google Drive folder. The development environment could not retrieve that private/shared folder reliably. A small embedded demo dataset is included only for reproducibility of the interface. The final submission must use the official dataset.

## Methodology
- Data cleaning: duplicates, invalid prices, missing values.
- Feature engineering: journey day/month, duration in minutes, numeric stop count.
- Encoding: one-hot encoding for categorical fields.
- Model: Random Forest Regressor.
- Evaluation: MAE and R² on a held-out test set.
- Part 3: average price by departure hour and cheapest options.

## Technologies Used
Python, Pandas, NumPy, Matplotlib, Scikit-learn, Streamlit, Pytest.

## Results
The application computes evaluation metrics dynamically after the official dataset is uploaded. This is preferable to hard-coding an unsupported result.

## Challenges Faced
The largest practical challenge was inconsistent flight-data schemas. The pipeline therefore supports common aliases and performs robust parsing of duration and stop-count fields. Another challenge is avoiding misleading conclusions from observational price data.

## Future Improvements
Use time-series validation, gradient boosting, SHAP, route-level models, and permitted live price sources.
