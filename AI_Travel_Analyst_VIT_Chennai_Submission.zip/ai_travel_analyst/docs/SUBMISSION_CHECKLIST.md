# Final Submission Checklist

- [ ] Choose Data Science & Visualisation track.
- [ ] Replace demo data with the mandatory official club dataset.
- [ ] Verify all five visualizations render.
- [ ] Verify model metrics render.
- [ ] Verify Part 3 cheapest-booking-time analysis renders.
- [ ] Run `pytest -q`.
- [ ] Record 3–5 minute demo.
- [ ] Create public GitHub repository.
- [ ] Push all commits.
- [ ] Verify README, requirements, source, tests and screenshots.
