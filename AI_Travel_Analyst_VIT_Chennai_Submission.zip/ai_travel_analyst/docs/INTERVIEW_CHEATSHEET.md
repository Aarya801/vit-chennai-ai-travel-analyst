# Interview Cheatsheet

**Why Random Forest?** It handles nonlinear relationships and mixed feature types well with limited preprocessing.

**Why not claim accuracy?** This is regression. MAE and R² are more appropriate than classification accuracy.

**Why feature engineering?** Raw duration/date/stop fields are not directly useful to many models; engineered numeric features expose meaningful structure.

**Why Streamlit?** It turns the Python pipeline into an interactive demo quickly and is easy to explain.

**How can the model be improved?** Time-aware validation, gradient boosting, route-level models, SHAP, and better external data.

**Main limitation?** Historical prices are observational and can change due to inventory, seasonality, demand, and airline pricing policies.

**How did you avoid fake results?** Metrics are calculated on the uploaded dataset at runtime rather than written as predetermined numbers.
