# 3–5 Minute Demo Script

1. **Opening (20 sec):** “This is AI Travel Analyst, built for the VIT Chennai AIML recruitment challenge. It analyzes flight prices and provides an evidence-based booking-time view.”
2. **Dataset (30 sec):** Upload the official challenge CSV. Point out rows, columns and median price.
3. **Exploration (60 sec):** Walk through the five visualizations: price distribution, airline effect, stops, routes, duration vs price.
4. **Model (60 sec):** Explain preprocessing, one-hot encoding, Random Forest, MAE and R².
5. **Part 3 (45 sec):** Show average price by departure hour and the cheapest recommendations.
6. **Engineering (30 sec):** Show README, tests, clean modules, and Git history.
7. **Close (20 sec):** Explain one limitation and one future improvement.
