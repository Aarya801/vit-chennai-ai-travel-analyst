import pandas as pd
from src.pipeline import clean_data, build_model, recommend_cheapest

def sample():
    return pd.DataFrame({'Airline':['A','B','A','C','B','C'], 'Source':['X']*6, 'Destination':['Y']*6, 'Total_Stops':['non-stop','1 stop','2 stops','non-stop','1 stop','2 stops'], 'Duration':['2h 0m','3h 0m','4h 0m','2h 30m','3h 30m','5h 0m'], 'Price':[100,200,300,120,220,330]})

def test_clean_adds_duration_and_stops():
    d=clean_data(sample())
    assert 'Duration_Min' in d.columns
    assert d['Total_Stops'].max()==2

def test_model_and_recommendation():
    d=clean_data(sample())
    _, metrics=build_model(d)
    assert 'r2' in metrics and 'mae' in metrics
    assert recommend_cheapest(d, 2).iloc[0]['Price']==100
