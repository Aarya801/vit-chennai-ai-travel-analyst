# Dataset

The challenge says the recommended/club dataset is mandatory for Part 1. The exact Google Drive folder shown in the brief could not be fetched from this environment, so this repository includes a small demo CSV only to make the application runnable.

**Before submission:** download the official club dataset from the link in the challenge brief and place the CSV in this directory (or upload it through the Streamlit sidebar). Do not claim the demo CSV is the club dataset.

A public alternative for experimentation is the Hugging Face recruitment/job-description collection: https://huggingface.co/datasets?other=job-description
