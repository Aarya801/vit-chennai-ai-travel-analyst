# Push to GitHub

1. Create a **public empty repository** on GitHub, e.g. `vit-chennai-ai-travel-analyst`.
2. Open a terminal in this project folder.
3. Run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/vit-chennai-ai-travel-analyst.git
git branch -M main
git push -u origin main
```

Do not commit API keys or private datasets.
