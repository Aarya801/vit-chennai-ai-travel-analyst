from src.pipeline import clean_data, build_model
import pandas as pd

df = pd.DataFrame({'Airline':['A','B','A'], 'Source':['X','X','Y'], 'Destination':['Y','Z','Z'], 'Total_Stops':['non-stop','1 stop','2 stops'], 'Duration':['2h 0m','4h 30m','6h 0m'], 'Price':[100,200,300]})
model, metrics = build_model(df)
print('OK', metrics)
