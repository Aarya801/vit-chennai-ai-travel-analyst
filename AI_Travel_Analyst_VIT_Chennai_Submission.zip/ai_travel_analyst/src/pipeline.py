from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

TARGET = 'Price'


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    aliases = {
        'price': 'Price', 'Price': 'Price',
        'airline': 'Airline', 'source': 'Source', 'destination': 'Destination',
        'total_stops': 'Total_Stops', 'stops': 'Total_Stops',
        'date_of_journey': 'Date_of_Journey', 'journey_date': 'Date_of_Journey',
        'dep_time': 'Dep_Time', 'departure_time': 'Dep_Time',
        'arrival_time': 'Arrival_Time', 'duration': 'Duration',
    }
    for c in list(df.columns):
        key = c.lower().replace(' ', '_')
        if key in aliases and aliases[key] not in df.columns:
            df.rename(columns={c: aliases[key]}, inplace=True)
    return df


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    df = normalize_columns(df)
    if 'Date_of_Journey' in df:
        dt = pd.to_datetime(df['Date_of_Journey'], errors='coerce', dayfirst=True)
        df['Journey_Day'] = dt.dt.day
        df['Journey_Month'] = dt.dt.month
        df.drop(columns=['Date_of_Journey'], inplace=True)
    if 'Duration' in df:
        s = df['Duration'].astype(str)
        df['Duration_Min'] = (
            s.str.extract(r'(\d+)\s*h', expand=False).fillna(0).astype(float) * 60
            + s.str.extract(r'(\d+)\s*m', expand=False).fillna(0).astype(float)
        )
    if 'Total_Stops' in df:
        stop_map = {'non-stop': 0, 'non stop': 0, '1 stop': 1, '2 stops': 2, '3 stops': 3, '4 stops': 4}
        df['Total_Stops'] = df['Total_Stops'].replace(stop_map)
        df['Total_Stops'] = pd.to_numeric(df['Total_Stops'], errors='coerce')
    if 'Price' in df:
        df['Price'] = pd.to_numeric(df['Price'], errors='coerce')
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = preprocess(df)
    df = df.drop_duplicates().reset_index(drop=True)
    if TARGET in df:
        df = df[df[TARGET].notna() & (df[TARGET] > 0)]
    return df


def build_model(df: pd.DataFrame):
    df = clean_data(df)
    X = df.drop(columns=[TARGET], errors='ignore')
    y = df[TARGET]
    numeric = X.select_dtypes(include=np.number).columns.tolist()
    categorical = [c for c in X.columns if c not in numeric]
    pre = ColumnTransformer([
        ('num', SimpleImputer(strategy='median'), numeric),
        ('cat', Pipeline([('imputer', SimpleImputer(strategy='most_frequent')), ('onehot', OneHotEncoder(handle_unknown='ignore'))]), categorical),
    ])
    model = Pipeline([('preprocess', pre), ('model', RandomForestRegressor(n_estimators=180, random_state=42, n_jobs=-1))])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {'mae': float(mean_absolute_error(y_test, pred)), 'r2': float(r2_score(y_test, pred))}
    return model, metrics


def recommend_cheapest(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    df = clean_data(df)
    cols = [c for c in ['Airline','Source','Destination','Dep_Time','Arrival_Time','Duration','Total_Stops','Price'] if c in df.columns]
    return df.sort_values('Price')[cols].head(top_n)
